"""
kos_Htools.telethon_core - Модуль для работы с Telegram API
"""

from .clients import MultiAccountManager
from .settings import TelegramAPI

__all__ = ["MultiAccountManager", "TelegramAPI"] 