"""
kos_Htools.telethon_core.utils - Утилиты для работы с Telegram
"""

from .parse import UserParse

__all__ = ["UserParse"] 