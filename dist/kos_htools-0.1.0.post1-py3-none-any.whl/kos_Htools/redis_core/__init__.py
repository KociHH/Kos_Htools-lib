"""
kos_Htools.redis_core - Модуль для работы с Redis
"""

from .redisetup import RedisBase

__all__ = ["RedisBase"] 